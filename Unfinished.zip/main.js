// event listeners
document.addEventListener("keydown", keydownHandler);
document.addEventListener("keydown", Transition);


let cnv = document.getElementById("GameScreen");
let ctx = cnv.getContext("2d");


cnv.width = 790;
cnv.height = 628;


// background
let CurrentBackground = [document.getElementById("scpImage")]
let Title = document.getElementById("TitleImg");
let Background = document.getElementById("BackgroundImg");
let BackgroundNumber = 0;
let Box1X = -395;
let Box2X = 790;
let Add = 10;
let Add2 = -10;


let r = 255;
let g = 255;
let b = 255;

requestAnimationFrame(TitleScreen);
function TitleScreen(){
    ctx.drawImage(Background, 0, 0, cnv.width, cnv.height);
    ctx.drawImage(Title, 100, 0, 640, 360);
    ctx.font = "30px Arial";
    ctx.fillStyle = "rgb("+ r +"," + g + "," + b + ")";
    ctx.fillText("Press Enter To play", 270, 550);
}


function keydownHandler(){
    if(Box1X == ){
        BackgroundNumber = 1;
    }
    if(BackgroundNumber == 1){
        ctx.drawImage(CurrentBackground[0], 0, 0, cnv.width,cnv.height);
        ctx.font = "30px Arial";
        ctx.fillStyle = ("red");
        ctx.fillText("Warning:", 335, 240);
        ctx.font = "30px Arial";
        ctx.fillStyle = ("white");
        ctx.fillText("The following content is classified information.", 100, 300);
        ctx.font = "30px Arial";
        ctx.fillStyle = ("white");
        ctx.fillText("Only personnel with level 5 access are authorized", 100, 350);
        ctx.font = "30px Arial";
        ctx.fillStyle = ("white");
        ctx.fillText("to see the contents of this game.", 170, 400);
    }
    requestAnimationFrame(keydownHandler);
}

// this animates transitions for everytime a cutsceen ends/starts
function Transition(){
    // this makes the animation for the curtains
    if(Box1X <= -10){
        Box1X += Add;
    }else if(Box1X = -10){
        Add = -10;
    }else if(Box1X = -395){
        Box1X = -395;
    }
    // this also animates the curtains
    if(Box2X >= 395){
        Box2X += Add2
    }else if(Box2X = 395){
        Add2 = 10;
    }else if(Box2X = 800){
        Box2X = 800;
    }
    ctx.fillStyle = "red";
    ctx.fillRect(Box1X, 0, 395, 630);

    ctx.fillStyle = "red";
    ctx.fillRect(Box2X, 0, 395, 630);

    BackgroundNumber = 1;

    requestAnimationFrame(Transition);
}
