document.getElementById("Rock"), addEventListener("click", Rock);
document.getElementById("Paper"), addEventListener("click", Paper);
document.getElementById("Scissor"), addEventListener("click", Scissor);
document.getElementById("Reset"), addEventListener("click", reset);

let cnv = document.getElementById("myCanvas");
let ctx = cnv.getContext("2d");


cnv.width = 500;
cnv.height = 500;

// global varaibles
let currentImage = document.getElementById("fistImg");
let number;


function Rock(){
    number = Math.floor(Math.random() * 3);
}
function Paper(){
    number = Math.floor(Math.random() * 3);
}
function Scissor(){
    number = Math.floor(Math.random() * 3);
}
function reset(){
    number = 5;
}

requestAnimationFrame(Background);
function Background(){

    if(number == 0){
        currentImage = document.getElementById("RockImg");
    }else if(number == 1){
        currentImage = document.getElementById("PaperImg");
    }else if(number == 2){
        currentImage = document.getElementById("ScissorImg");
    }else if(number == 5){
        currentImage = document.getElementById("fistImg");
    }


    ctx.fillRect(0, 0, cnv.width, cnv.height);
    ctx.fillStyle = "white";
    ctx.drawImage(currentImage, 0, 100, 500, 300);

    requestAnimationFrame(Background);    
}